export interface UserDataUsage {
  dataAmount: number;
}