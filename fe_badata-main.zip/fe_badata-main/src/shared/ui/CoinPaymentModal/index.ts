export { CoinPaymentModal } from './CoinPaymentModal';
