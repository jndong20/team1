export { DataUsageCard } from '@/shared/ui/DataUsageCard/DataUsageCard';
export type { DataUsageCardProps } from '@/shared/ui/DataUsageCard/DataUsageCard';

