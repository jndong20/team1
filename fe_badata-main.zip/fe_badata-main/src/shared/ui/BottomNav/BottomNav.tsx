'use client';

import Image from 'next/image';
import { usePathname, useRouter } from 'next/navigation';

import { ShoppingCart, ThumbsUp, User, Wifi, X } from 'lucide-react';

import { useAuthStore } from '@/entities/auth/model/authStore';
import { PATH } from '@/shared/config/path';
import { useAuthErrorStore } from '@/shared/lib/axios/authErrorStore';
import { useSosDrawer } from '@/widgets/sos/model/useSosDrawer';

import { WAVE_CLIP_PATH } from './constants';

const NAV_CONFIG = [
  { label: '추천', path: PATH.RECOMMEND, icon: ThumbsUp },
  { label: '거래', path: PATH.TRADE.MAIN, icon: ShoppingCart },
  { label: '대여', path: PATH.RENTAL.MAIN, icon: Wifi },
  { label: '마이', path: PATH.MYPAGE.MAIN, icon: User },
];

const NavItem = ({
  item,
  isActive,
  onClick,
}: {
  item: (typeof NAV_CONFIG)[0];
  isActive: boolean;
  onClick: () => void;
}) => {
  const Icon = item.icon;
  return (
    <li className="flex-1 flex flex-col items-center justify-end pb-3">
      <button onClick={onClick} className="flex flex-col items-center gap-1 cursor-pointer">
        <Icon
          size={24}
          stroke={isActive ? 'var(--main-3)' : 'var(--gray-light)'}
          strokeWidth={isActive ? 2.5 : 2}
        />
        <span
          className={`text-xs font-bold ${isActive ? 'text-[var(--main-3)]' : 'text-[var(--gray-light)]'}`}
        >
          {item.label}
        </span>
      </button>
    </li>
  );
};

export const BottomNav = () => {
  const { isDrawerOpen, toggleDrawer } = useSosDrawer();
  const pathname = usePathname() ?? '';
  const router = useRouter();
  const isLoggedIn = useAuthStore((state) => state.isLoggedIn);
  const { openAuthModalForNavigation } = useAuthErrorStore();

  const getActiveIdx = () => {
    return NAV_CONFIG.findIndex((item) => pathname.startsWith(item.path));
  };
  const activeIdx = getActiveIdx();

  const handleNavigation = (path: string) => {
    // 추천 페이지인 경우 로그인 체크
    if (path === PATH.RECOMMEND && !isLoggedIn) {
      openAuthModalForNavigation(path);
      return;
    }

    // 그 외 페이지는 바로 이동
    router.push(path);
  };

  return (
    <nav className="relative bottom-0 inset-x-0 h-[80px]">
      {/* 파도 형태 */}
      <div
        className="absolute bottom-0 left-0 w-full h-[80px] bg-[var(--main-5)]"
        style={{
          clipPath: WAVE_CLIP_PATH,
        }}
      />

      <ul className="relative flex w-full justify-between items-end px-2 z-10 h-full">
        {NAV_CONFIG.slice(0, 2).map((item, idx) => (
          <NavItem
            key={item.label}
            item={item}
            isActive={activeIdx === idx}
            onClick={() => handleNavigation(item.path)}
          />
        ))}

        {/* SOS 버튼 */}
        <li className=" relative mb-6 z-20 flex flex-col items-center transition-transform duration-300">
          <button
            onClick={toggleDrawer}
            className={`cursor-pointer w-[80px] h-[80px] rounded-full flex items-center justify-center transition-color duration-100 ${
              isDrawerOpen ? 'bg-black' : 'none'
            }`}
          >
            {isDrawerOpen ? (
              <div className="flex flex-col items-center text-white justify-center transition-opacity duration-200">
                <X />
                <span className="text-[14px] font-semibold">닫기</span>
              </div>
            ) : (
              <Image
                src="/images/sos-button.svg"
                alt="SOS"
                width={80}
                height={80}
                draggable={false}
                priority
              />
            )}
          </button>
        </li>

        {NAV_CONFIG.slice(2).map((item, idx) => (
          <NavItem
            key={item.label}
            item={item}
            isActive={activeIdx === idx + 2}
            onClick={() => handleNavigation(item.path)}
          />
        ))}
      </ul>
    </nav>
  );
};
