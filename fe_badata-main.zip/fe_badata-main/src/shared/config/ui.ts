export const HEADER_WIDTH = {
  MAX: 428,
  MIN: 420,
};
