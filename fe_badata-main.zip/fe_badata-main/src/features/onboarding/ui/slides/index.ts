export { OnboardingBackground } from './OnboardingBackground';
export { Slide1 } from './Slide1';
export { Slide2 } from './Slide2';
export { Slide3 } from './Slide3';
export { Slide4 } from './Slide4';
export { Slide5 } from './Slide5';
export { Slide6 } from './Slide6';
