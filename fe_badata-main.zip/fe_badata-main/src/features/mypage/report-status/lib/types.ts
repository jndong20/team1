export interface ReportStatus {
  questionCount: number;
  answerCount: number;
  completeCount: number;
}