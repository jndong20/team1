import FollowingPage from '@/features/mypage/following/page/FollowingPage';

export const dynamic = 'force-dynamic';

export default function Page() {
  return <FollowingPage />;
}
