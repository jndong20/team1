import RestockAlarmPage from '@/features/mypage/restock-alarm/page/RestockAlarmPage';
export const dynamic = 'force-dynamic';

export default function Page() {
  return <RestockAlarmPage />;
}
