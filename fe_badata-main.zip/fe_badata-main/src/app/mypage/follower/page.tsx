import FollowerPage from '@/features/mypage/follower/page/FollowerPage';
export const dynamic = 'force-dynamic';

export default function Page() {
  return <FollowerPage />;
}
