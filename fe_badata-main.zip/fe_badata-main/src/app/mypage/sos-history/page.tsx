import SosHistoryPage from '@/features/mypage/sos-history/page/SosHistoryPage';

export const dynamic = 'force-dynamic';

export default function Page() {
  return <SosHistoryPage />;
}
