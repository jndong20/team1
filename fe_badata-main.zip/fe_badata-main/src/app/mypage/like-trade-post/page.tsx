import LikeTradePostPage from '@/features/mypage/like-trade-post/page/LikeTradePostPage';

export const dynamic = 'force-dynamic';

export default function Page() {
  return <LikeTradePostPage />;
}
