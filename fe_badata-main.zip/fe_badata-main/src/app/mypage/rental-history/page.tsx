import RentalHistoryPage from '@/features/mypage/rental-history/page/RentalHistoryPage';

export const dynamic = 'force-dynamic';

export default function Page() {
  return <RentalHistoryPage />;
}
