import ReportHistoryPage from '@/features/mypage/report-history/page/ReportHistoryPage';
export const dynamic = 'force-dynamic';
export default function Page() {
  return <ReportHistoryPage />;
}
