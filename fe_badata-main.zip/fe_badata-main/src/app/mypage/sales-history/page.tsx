import SalesHistoryPage from '@/features/mypage/sales-history/page/SalesHistoryPage';

export const dynamic = 'force-dynamic';

export default function Page() {
  return <SalesHistoryPage />;
}
