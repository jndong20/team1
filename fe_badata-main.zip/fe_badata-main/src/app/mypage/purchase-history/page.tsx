import PurchaseHistoryPage from '@/features/mypage/purchase-history/page/PurchaseHistoryPage';

export const dynamic = 'force-dynamic';
export default function Page() {
  return <PurchaseHistoryPage />;
}
