import AlarmSettingPage from '@/features/mypage/alarm-setting/page/AlarmSettingPage';
export const dynamic = 'force-dynamic';

export default function Page() {
  return <AlarmSettingPage />;
}
