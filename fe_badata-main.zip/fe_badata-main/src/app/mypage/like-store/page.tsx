import LikeStorePage from '@/features/mypage/like-store/page/LikeStorePage';

export const dynamic = 'force-dynamic';

export default function Page() {
  return <LikeStorePage />;
}
