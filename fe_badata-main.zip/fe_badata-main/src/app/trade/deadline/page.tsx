import DeadlinePage from '@/features/trade/deadline/page/DeadlinePage';
export const dynamic = 'force-dynamic';

export default function Page() {
  return <DeadlinePage />;
}
