import RegisterGifticonPage from '@/features/trade/register/gifticon/page/RegisterGifticonPage';

export const dynamic = 'force-dynamic';

export default function Page() {
  return <RegisterGifticonPage />;
}
