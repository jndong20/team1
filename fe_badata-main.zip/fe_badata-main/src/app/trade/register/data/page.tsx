import DataRegisterPage from '@/features/trade/register/data/page/DataRegisterPage';

export const dynamic = 'force-dynamic';

export default function Page() {
  return <DataRegisterPage />;
}
